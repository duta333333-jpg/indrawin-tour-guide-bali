# Indrawin Tour Guide Bali - Ready to Deploy

This package contains two versions:
- Version A: Single-page bilingual (index.html) with language switcher (ID/EN)
- Version B: SEO-friendly separate pages (/id/index.html and /en/index.html)

## Files
- index.html (single-page bilingual)
- id/index.html (Indonesian page)
- en/index.html (English page)
- README.md (this file)

## Quick Deploy - GitHub Pages (Web UI)
1. Login to your GitHub account (the same account you use here).
2. Create a new repository named `indrawin-tour-guide-bali`.
3. Upload all files and folders from this ZIP into the repository (you can drag & drop on GitHub).
4. Go to Settings → Pages → Source → choose `main` (or `master`) branch and root (/<root>), then Save.
5. Wait ~1 minute. Your site will be available at: `https://<username>.github.io/indrawin-tour-guide-bali/`

## Quick Deploy - Netlify (Drop)
1. Open https://app.netlify.com/drop
2. Drag and drop the ZIP file or the unzipped folder onto the page.
3. Netlify will publish the site and give you a link like `https://indrawin-tour-guide-bali.netlify.app/`

## Post-deploy (recommended)
- Verify site in Google Search Console and request indexing to show on Google faster.
- Add these meta descriptions and sitemap if needed.

Contact: WhatsApp: 0821-4504-7524 | Email: duta333333@gmail.com
